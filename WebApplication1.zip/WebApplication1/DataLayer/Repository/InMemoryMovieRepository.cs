﻿using DataLayer.DataGenerator;
using DataLayer.Entities;
using DataLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DataLayer.Repository
{
    public class InMemoryMovieRepository : IMoviesRepository
    {
         readonly MoviesGenerator _moviesGenerator;
        public InMemoryMovieRepository(MoviesGenerator moviesGenerator)
        {
            _moviesGenerator = moviesGenerator ?? throw new ArgumentNullException();
        }
        public void AddMovie(Movie movie)
        {
            throw new NotImplementedException();
        }

        public Movie GetMovieById(int movieId)
        {
           return _moviesGenerator.GetAllMovies().Where(x => x.Id == movieId).FirstOrDefault();
        }
    }
}
