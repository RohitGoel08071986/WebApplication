﻿using System;

namespace DataLayer
{
    public class Class1
    {
    }
}
