﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusinessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        readonly IManageMovies _manageMovies;
        public MoviesController(IManageMovies manageMovies)
        {
            _manageMovies = manageMovies ?? throw new ArgumentNullException();
        }
       [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var movie=_manageMovies.GetMovie(id);
            return Ok(movie);
        }
    }
  
}

