using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Movies.L1.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
