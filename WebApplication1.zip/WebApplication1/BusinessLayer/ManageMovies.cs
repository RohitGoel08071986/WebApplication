﻿using DataLayer.Entities;
using DataLayer.Interfaces;
using System;

namespace BusinessLayer
{
    public class ManageMovies : IManageMovies
    {
        readonly IMoviesRepository _moviesRepository;
        public ManageMovies(IMoviesRepository moviesRepository)
        {
            _moviesRepository = moviesRepository ?? throw new ArgumentNullException();
        }
        public void AddNewMovie(Movie movie)
        {

        }

        public Movie GetMovie(int id)
        {
           return _moviesRepository.GetMovieById(id);

        }
    }

    public interface IManageMovies
    {
        void AddNewMovie(Movie movie);
        Movie GetMovie(int id);
    }
}
